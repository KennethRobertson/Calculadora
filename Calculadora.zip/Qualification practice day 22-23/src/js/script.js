
const calculatorText = document.querySelector("#calculator-text")
let lastDigit = ""

let inputValue = document.querySelectorAll(".calculator-button")

inputValue.forEach((btn) => {btn.addEventListener("click", (event) => {
        let value = (event.target.value);

        if (value == 1 ||
            value == 2 ||
            value == 3 ||
            value == 4 ||
            value == 5 ||
            value == 6 ||
            value == 7 ||
            value == 8 ||
            value == 9 ||
            value == 0)
        {
            calculatorText.textContent += value;
            lastDigit = value;
        }
        else if(value == "AC")
            {
                calculatorText.textContent = ""
                lastDigit = ""
            }
        else if(value == "=" &&
            lastDigit != "" &&
            lastDigit != "." &&
            lastDigit != "/" &&
            lastDigit != "-" &&
            lastDigit != "+" &&
            lastDigit != "*")
        {
            calculatorText.textContent = eval(calculatorText.textContent)
        }
        else if (value == "-" && lastDigit != "-"){
            calculatorText.textContent += value;
            lastDigit = value;
        }
        else{
            if (lastDigit == "" ||
                lastDigit == "." ||
                lastDigit == "/" ||
                lastDigit == "-" ||
                lastDigit == "+" ||
                lastDigit == "*")
            {
                lastDigit = value;
            }
            else{
                calculatorText.textContent += value;
                lastDigit = value;
            }
        }
    })
});